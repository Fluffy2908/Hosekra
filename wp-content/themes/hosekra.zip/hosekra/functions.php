<?php
/**
 * Hosekra Theme Functions
 *
 * Modular structure based on Curiosity theme pattern
 */

// Theme setup and configuration
require_once get_template_directory() . '/inc/theme.php';

// Enqueue scripts and styles
require_once get_template_directory() . '/inc/enqueue.php';

// Custom Post Types
require_once get_template_directory() . '/inc/cpt/cpt-mobilhaus.php';

// ACF Blocks and Fields
require_once get_template_directory() . '/inc/acf.php';
